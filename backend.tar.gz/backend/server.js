const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const path = require('path');

// Load environment variables
dotenv.config();

// Import database and models
const { sequelize, testConnection } = require('./config/database');
const models = require('./models');

// Import routes
const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/users');
const productRoutes = require('./routes/products');
const categoryRoutes = require('./routes/categories');
const orderRoutes = require('./routes/orders');
const subscriptionRoutes = require('./routes/subscriptions');
const trainerRoutes = require('./routes/trainers');
const workoutRoutes = require('./routes/workouts');
const mealRoutes = require('./routes/meals');
const progressRoutes = require('./routes/progress');
const workshopRoutes = require('./routes/workshops');
const adminRoutes = require('./routes/admin');
const settingsRoutes = require('./routes/settings');
const notificationRoutes = require('./routes/notifications');
const couponRoutes = require('./routes/coupons');
const cartRoutes = require('./routes/cart');
const reviewRoutes = require('./routes/reviews');
const dashboardRoutes = require('./routes/dashboard');

// Initialize Express app
const app = express();

// Middleware
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Static files for uploads
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Static files for admin dashboard
app.use('/admin-panel', express.static(path.join(__dirname, 'public/admin')));

// Static files for trainer dashboard
app.use('/trainer-panel', express.static(path.join(__dirname, 'public/trainer')));

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/products', productRoutes);
app.use('/api/categories', categoryRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/subscriptions', subscriptionRoutes);
app.use('/api/trainers', trainerRoutes);
app.use('/api/workouts', workoutRoutes);
app.use('/api/meals', mealRoutes);
app.use('/api/progress', progressRoutes);
app.use('/api/workshops', workshopRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/settings', settingsRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/coupons', couponRoutes);
app.use('/api/cart', cartRoutes);
app.use('/api/reviews', reviewRoutes);
app.use('/api/dashboard', dashboardRoutes);

// Welcome route
app.get('/', (req, res) => {
  res.json({
    message: 'VitaFit API Server',
    version: '2.0.0',
    status: 'Running',
    database: 'MySQL',
    documentation: '/api/docs'
  });
});

// API documentation route
app.get('/api', (req, res) => {
  res.json({
    message: 'VitaFit API v2.0',
    endpoints: {
      auth: '/api/auth - Authentication (login, register, profile)',
      users: '/api/users - User management',
      products: '/api/products - Product catalog',
      categories: '/api/categories - Product categories',
      orders: '/api/orders - Order management',
      subscriptions: '/api/subscriptions - Subscription plans',
      trainers: '/api/trainers - Trainer management',
      workouts: '/api/workouts - Workout programs',
      meals: '/api/meals - Meal plans & nutrition',
      progress: '/api/progress - Progress tracking',
      workshops: '/api/workshops - Workshops & events',
      admin: '/api/admin - Admin operations',
      settings: '/api/settings - App settings',
      notifications: '/api/notifications - Push notifications',
      coupons: '/api/coupons - Discount coupons',
      cart: '/api/cart - Shopping cart',
      reviews: '/api/reviews - Product reviews',
      dashboard: '/api/dashboard - Dashboard statistics'
    }
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: 'Endpoint not found'
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error:', err.message);
  console.error('Stack:', err.stack);

  res.status(err.status || 500).json({
    success: false,
    message: process.env.NODE_ENV === 'production'
      ? 'Internal Server Error'
      : err.message,
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
});

// Start server
const startServer = async () => {
  try {
    // Test database connection
    await testConnection();

    // Sync database (create tables if not exist)
    const syncOptions = {
      alter: process.env.NODE_ENV === 'development' ? true : false
    };

    await sequelize.sync(syncOptions);
    console.log('✅ Database synchronized');

    // Start server
    const PORT = process.env.PORT || 5000;
    const HOST = '0.0.0.0';

    app.listen(PORT, HOST, () => {
      console.log('========================================');
      console.log('🚀 VitaFit API Server Started!');
      console.log('========================================');
      console.log(`📊 Environment: ${process.env.NODE_ENV || 'development'}`);
      console.log(`🌐 Server: http://${HOST}:${PORT}`);
      console.log(`📁 API Docs: http://localhost:${PORT}/api`);
      console.log('========================================');
    });
  } catch (error) {
    console.error('❌ Failed to start server:', error);
    process.exit(1);
  }
};

startServer();

// Handle unhandled promise rejections
process.on('unhandledRejection', (err) => {
  console.error('Unhandled Rejection:', err);
});

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception:', err);
  process.exit(1);
});

module.exports = app;
