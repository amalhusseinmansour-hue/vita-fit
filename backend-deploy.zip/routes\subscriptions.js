const express = require('express');
const { protect } = require('../middleware/auth');
const Subscription = require('../models/Subscription');

const router = express.Router();

router.post('/subscribe', protect, async (req, res) => {
  try {
    const { plan, planName, price } = req.body;
    const startDate = new Date();
    const endDate = new Date();
    if (plan === 'monthly') endDate.setMonth(endDate.getMonth() + 1);
    else if (plan === 'quarterly') endDate.setMonth(endDate.getMonth() + 3);
    else if (plan === 'yearly') endDate.setFullYear(endDate.getFullYear() + 1);

    const subscription = await Subscription.create({
      user: req.user.id,
      plan,
      planName,
      price,
      startDate,
      endDate,
    });
    res.status(201).json({ success: true, data: subscription });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/my-subscription', protect, async (req, res) => {
  try {
    const subscription = await Subscription.findOne({ user: req.user.id, status: 'active' });
    res.json({ success: true, data: subscription });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
