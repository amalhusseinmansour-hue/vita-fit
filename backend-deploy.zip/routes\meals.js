const express = require('express');
const { protect } = require('../middleware/auth');
const Meal = require('../models/Meal');

const router = express.Router();

router.get('/', protect, async (req, res) => {
  try {
    const meals = await Meal.find({ user: req.user.id }).sort('-date');
    res.json({ success: true, data: meals });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.post('/', protect, async (req, res) => {
  try {
    const meal = await Meal.create({ ...req.body, user: req.user.id });
    res.status(201).json({ success: true, data: meal });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/daily-nutrition', protect, async (req, res) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const meals = await Meal.find({ user: req.user.id, date: { $gte: today } });
    const totalNutrition = meals.reduce((acc, meal) => {
      acc.calories += meal.totalNutrition.calories;
      acc.protein += meal.totalNutrition.protein;
      acc.carbs += meal.totalNutrition.carbs;
      acc.fat += meal.totalNutrition.fat;
      return acc;
    }, { calories: 0, protein: 0, carbs: 0, fat: 0 });
    res.json({ success: true, data: totalNutrition });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
