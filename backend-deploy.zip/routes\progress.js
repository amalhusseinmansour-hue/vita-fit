const express = require('express');
const { protect } = require('../middleware/auth');
const Progress = require('../models/Progress');
const User = require('../models/User');

const router = express.Router();

// Get all progress entries for user
router.get('/', protect, async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    const filter = { user: req.user.id };

    if (startDate || endDate) {
      filter.date = {};
      if (startDate) filter.date.$gte = new Date(startDate);
      if (endDate) filter.date.$lte = new Date(endDate);
    }

    const progress = await Progress.find(filter).sort('-date');
    res.json({ success: true, data: progress });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Get latest progress entry
router.get('/latest', protect, async (req, res) => {
  try {
    const progress = await Progress.findOne({ user: req.user.id }).sort('-date');

    if (!progress) {
      return res.status(404).json({ success: false, message: 'No progress data found' });
    }

    res.json({ success: true, data: progress });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Create progress entry
router.post('/', protect, async (req, res) => {
  try {
    const progress = await Progress.create({
      ...req.body,
      user: req.user.id,
    });

    res.status(201).json({ success: true, data: progress });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Get progress by ID
router.get('/:id', protect, async (req, res) => {
  try {
    const progress = await Progress.findOne({
      _id: req.params.id,
      user: req.user.id,
    });

    if (!progress) {
      return res.status(404).json({ success: false, message: 'Progress entry not found' });
    }

    res.json({ success: true, data: progress });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Update progress entry
router.put('/:id', protect, async (req, res) => {
  try {
    const progress = await Progress.findOneAndUpdate(
      { _id: req.params.id, user: req.user.id },
      req.body,
      { new: true, runValidators: true }
    );

    if (!progress) {
      return res.status(404).json({ success: false, message: 'Progress entry not found' });
    }

    res.json({ success: true, data: progress });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Delete progress entry
router.delete('/:id', protect, async (req, res) => {
  try {
    const progress = await Progress.findOneAndDelete({
      _id: req.params.id,
      user: req.user.id,
    });

    if (!progress) {
      return res.status(404).json({ success: false, message: 'Progress entry not found' });
    }

    res.json({ success: true, message: 'Progress entry deleted' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Get progress statistics
router.get('/stats/summary', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    const allProgress = await Progress.find({ user: req.user.id }).sort('date');

    if (allProgress.length === 0) {
      return res.json({
        success: true,
        data: {
          totalEntries: 0,
          weightChange: 0,
          averageWeightChange: 0,
          currentBMI: null,
        },
      });
    }

    const latest = allProgress[allProgress.length - 1];
    const oldest = allProgress[0];
    const weightChange = (latest.weight - oldest.weight).toFixed(1);
    const averageWeightChange = (weightChange / allProgress.length).toFixed(2);

    const stats = {
      totalEntries: allProgress.length,
      weightChange: parseFloat(weightChange),
      averageWeightChange: parseFloat(averageWeightChange),
      currentWeight: latest.weight,
      startingWeight: oldest.weight,
      currentBMI: user.height ? latest.calculateBMI(user.height) : null,
      latestBodyFat: latest.bodyFatPercentage,
      latestMuscleMass: latest.muscleMass,
    };

    res.json({ success: true, data: stats });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Get weight history for chart
router.get('/stats/weight-history', protect, async (req, res) => {
  try {
    const { days = 30 } = req.query;
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - parseInt(days));

    const progress = await Progress.find({
      user: req.user.id,
      date: { $gte: startDate },
    }).sort('date');

    const weightHistory = progress.map(entry => ({
      date: entry.date,
      weight: entry.weight,
    }));

    res.json({ success: true, data: weightHistory });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
