const express = require('express');
const { protect, authorize } = require('../middleware/auth');
const Trainer = require('../models/Trainer');

const router = express.Router();

// Get all trainers
router.get('/', async (req, res) => {
  try {
    const { specialization, isActive } = req.query;
    const filter = {};

    if (specialization) filter.specialization = specialization;
    if (isActive !== undefined) filter.isActive = isActive === 'true';

    const trainers = await Trainer.find(filter)
      .select('-clients')
      .sort('-rating');

    res.json({ success: true, data: trainers });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Get trainer by ID
router.get('/:id', async (req, res) => {
  try {
    const trainer = await Trainer.findById(req.params.id)
      .populate('clients', 'name email');

    if (!trainer) {
      return res.status(404).json({ success: false, message: 'Trainer not found' });
    }

    res.json({ success: true, data: trainer });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Create trainer (admin only)
router.post('/', protect, authorize('admin'), async (req, res) => {
  try {
    const trainer = await Trainer.create(req.body);
    res.status(201).json({ success: true, data: trainer });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Update trainer (admin only)
router.put('/:id', protect, authorize('admin'), async (req, res) => {
  try {
    const trainer = await Trainer.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );

    if (!trainer) {
      return res.status(404).json({ success: false, message: 'Trainer not found' });
    }

    res.json({ success: true, data: trainer });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Delete trainer (admin only)
router.delete('/:id', protect, authorize('admin'), async (req, res) => {
  try {
    const trainer = await Trainer.findByIdAndDelete(req.params.id);

    if (!trainer) {
      return res.status(404).json({ success: false, message: 'Trainer not found' });
    }

    res.json({ success: true, message: 'Trainer deleted' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Assign client to trainer (admin only)
router.post('/:id/assign-client', protect, authorize('admin'), async (req, res) => {
  try {
    const { userId } = req.body;
    const trainer = await Trainer.findById(req.params.id);

    if (!trainer) {
      return res.status(404).json({ success: false, message: 'Trainer not found' });
    }

    if (!trainer.clients.includes(userId)) {
      trainer.clients.push(userId);
      await trainer.save();
    }

    res.json({ success: true, data: trainer });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
