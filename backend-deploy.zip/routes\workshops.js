const express = require('express');
const { protect, authorize } = require('../middleware/auth');
const Workshop = require('../models/Workshop');

const router = express.Router();

// Get all workshops
router.get('/', async (req, res) => {
  try {
    const { category, status, upcoming } = req.query;
    const filter = {};

    if (category) filter.category = category;
    if (status) filter.status = status;
    if (upcoming === 'true') filter.date = { $gte: new Date() };

    const workshops = await Workshop.find(filter)
      .populate('trainer', 'name specialization image rating')
      .sort('date');

    res.json({ success: true, data: workshops });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Get workshop by ID
router.get('/:id', async (req, res) => {
  try {
    const workshop = await Workshop.findById(req.params.id)
      .populate('trainer', 'name specialization image rating bio')
      .populate('participants', 'name email');

    if (!workshop) {
      return res.status(404).json({ success: false, message: 'Workshop not found' });
    }

    res.json({ success: true, data: workshop });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Create workshop (admin only)
router.post('/', protect, authorize('admin'), async (req, res) => {
  try {
    const workshop = await Workshop.create(req.body);
    res.status(201).json({ success: true, data: workshop });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Update workshop (admin only)
router.put('/:id', protect, authorize('admin'), async (req, res) => {
  try {
    const workshop = await Workshop.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    ).populate('trainer', 'name specialization image');

    if (!workshop) {
      return res.status(404).json({ success: false, message: 'Workshop not found' });
    }

    res.json({ success: true, data: workshop });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Delete workshop (admin only)
router.delete('/:id', protect, authorize('admin'), async (req, res) => {
  try {
    const workshop = await Workshop.findByIdAndDelete(req.params.id);

    if (!workshop) {
      return res.status(404).json({ success: false, message: 'Workshop not found' });
    }

    res.json({ success: true, message: 'Workshop deleted' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Register for workshop (protected)
router.post('/:id/register', protect, async (req, res) => {
  try {
    const workshop = await Workshop.findById(req.params.id);

    if (!workshop) {
      return res.status(404).json({ success: false, message: 'Workshop not found' });
    }

    if (workshop.isFull()) {
      return res.status(400).json({ success: false, message: 'Workshop is full' });
    }

    if (workshop.participants.includes(req.user.id)) {
      return res.status(400).json({ success: false, message: 'Already registered' });
    }

    if (workshop.status !== 'scheduled') {
      return res.status(400).json({ success: false, message: 'Workshop not available for registration' });
    }

    workshop.participants.push(req.user.id);
    await workshop.save();

    res.json({ success: true, data: workshop, message: 'Successfully registered' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Unregister from workshop (protected)
router.post('/:id/unregister', protect, async (req, res) => {
  try {
    const workshop = await Workshop.findById(req.params.id);

    if (!workshop) {
      return res.status(404).json({ success: false, message: 'Workshop not found' });
    }

    if (!workshop.participants.includes(req.user.id)) {
      return res.status(400).json({ success: false, message: 'Not registered for this workshop' });
    }

    workshop.participants = workshop.participants.filter(
      p => p.toString() !== req.user.id.toString()
    );
    await workshop.save();

    res.json({ success: true, data: workshop, message: 'Successfully unregistered' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Get user's registered workshops
router.get('/user/my-workshops', protect, async (req, res) => {
  try {
    const workshops = await Workshop.find({ participants: req.user.id })
      .populate('trainer', 'name specialization image rating')
      .sort('date');

    res.json({ success: true, data: workshops });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
