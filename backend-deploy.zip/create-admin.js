const mongoose = require('mongoose');
const User = require('./models/User');
require('dotenv').config();

async function createAdmin() {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('✅ Connected to MongoDB');

    // Check if admin exists
    const existingAdmin = await User.findOne({ email: 'admin@gym.com' });

    if (existingAdmin) {
      // Update existing user to admin
      existingAdmin.role = 'admin';
      await existingAdmin.save();
      console.log('✅ Updated existing user to admin');
      console.log('📧 Email: admin@gym.com');
      console.log('🔑 Password: admin123');
    } else {
      // Create new admin
      const admin = await User.create({
        name: 'Admin',
        email: 'admin@gym.com',
        password: 'admin123',
        role: 'admin',
        isActive: true
      });
      console.log('✅ Admin user created successfully!');
      console.log('📧 Email: admin@gym.com');
      console.log('🔑 Password: admin123');
    }

    process.exit(0);
  } catch (error) {
    console.error('❌ Error:', error.message);
    process.exit(1);
  }
}

createAdmin();
